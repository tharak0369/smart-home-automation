#include "header.h"
 char ch,flag=0,i=0,s3=0;
void uart_init(unsigned int baud)
{
 unsigned int result,pclk;
 char a[]={15,60,30,15};
 pclk=a[VPBDIV]*1000000;
 result=pclk/(16*baud);
 PINSEL0|=0x05;
 U0LCR=0X83;
 U0DLL=	result&0xff;
 U0DLM=	((result>>8)&0xff);
 U0LCR=0X03;

}

void uart_tx(char data)
{
 U0THR=data;
 while(((U0LSR>>5)&1)==0);
}


  void uart_tx_str(char *p)
  {
	while(*p)
	{
	 U0THR=*p;
	 while(((U0LSR>>5)&1)==0);
	 p++;
	}
  }
   char uart_rx(void)
   {
	while((U0LSR&1)==0);
	return U0RBR;
   }

  void intr_config_uart(void)
  {
   VICIntSelect=0;
   VICVectCntl0=6|(1<<5);
   VICVectCntl1=14|(1<<5);
   VICVectAddr1=(unsigned int)ext_handler;
   VICVectAddr0=(unsigned int)uart_handler;
   U0IER=1;
   PINSEL1|=1;
   EXTMODE=1;
   EXTPOLAR=0;
   VICIntEnable=1<<6|1<<14;
  }

  void ext_handler(void)__irq
  {
   s3=s3^1<<0;
   EXTINT=1;
   VICVectAddr=0;
  }

	void uart_handler(void)__irq
	{
	char r=U0IIR;
	if((r&0x0e)==4)
	  {
	   ch=U0RBR;
	   flag=1;
	  }
	   VICVectAddr=0;
	}









