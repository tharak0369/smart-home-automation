#include "header.h"
extern char s3,flag,ch;
int main()
{
 char s1=0,s2=0;
 uart_init(9600);
 intr_config_uart();
 IODIR0=LED1|LED2;
 IOSET0=LED1|LED2;

 while(1)
 {
  if(s3==0)
  {
   uart_tx_str("bluetooth mode\r\n");
   while(1)
   {
      if(s3==1)
      break;
   if(flag==1)
   {
   switch(ch)
   {
	 case 'a': IOCLR0=LED1;break;
	 case 'b': IOSET0=LED1;break;
	 case 'c': IOCLR0=LED2;break;
	 case 'd': IOSET0=LED2;break;
	}
	flag=0;
	}
   }
  }

   if(s3==1)
   {
	uart_tx_str("manual mode\r\n");
	while(1)
	{
	  if(SW1==0)
	  {
	   s1=s1^1<<0;
		while(SW1==0);
	   }
	   if(s1==1)
	   IOCLR0=LED1;
	   else
	   IOSET0=LED1;

	   if(SW2==0)
	   {
	   s2=s2^1<<0;
		while(SW2==0);
	   }
	   if(s2==1)
	   IOCLR0=LED2;
	   else
	   IOSET0=LED2;
	   if(s3==0)
	   break;
	 }
   }
 }
}
