#include<lpc21xx.h>


void uart_init(unsigned int baud);
 void uart_tx(char data);
  void uart_tx_str(char *p);
    void intr_config_uart(void);
	void uart_handler(void)__irq;

	#define SW1 ((IOPIN0>>14)&1)
	#define SW2 ((IOPIN0>>15)&1)
	#define SW3 ((IOPIN0>>16)&1)
	#define LED1 1<<17
	#define LED2 1<<18
char uart_rx(void);
 void ext_handler(void)__irq;

